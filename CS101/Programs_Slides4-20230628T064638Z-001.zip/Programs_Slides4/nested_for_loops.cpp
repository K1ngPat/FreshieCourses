#include <iostream>
using namespace std;

int main()
{
    int n,m;
    double avg,score;

    cout << "enter the number of students: "; cin >> n;
    cout << "enter the number of subjects: "; cin >> m;

    for (int i = 0; i < n ; i++)
    {
        cout << "enter marks for student number: " << i << endl;
        avg = 0;
        for (int j = 0; j < m; j++)
        {
            cout << "enter marks for subject " << j << " of student " << i << ": ";
            cin >> score;
            avg += score;
        } // close inner for loop (control variable j)
        avg = avg/m; cout << "Avg. marks for this student are: " << avg << endl;
    } // close outer for loop (control variable i)
} // close main_program
