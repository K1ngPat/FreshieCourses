var searchData=
[
  ['boot_5finfo_0',['boot_info',['../kernel_8c.html#a76271be06cbf672af652cef947c47cd8',1,'kernel.c']]],
  ['bug_20list_1',['Bug List',['../bug.html',1,'']]]
];
