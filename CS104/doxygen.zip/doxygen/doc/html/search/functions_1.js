var searchData=
[
  ['draw_5fchar_22',['draw_char',['../console_8c.html#a6a4b480cb4306993718003fdaf8d84d1',1,'draw_char(int row, int col, int ch, int color):&#160;console.c'],['../console_8h.html#a6a4b480cb4306993718003fdaf8d84d1',1,'draw_char(int row, int col, int ch, int color):&#160;console.c']]]
];
