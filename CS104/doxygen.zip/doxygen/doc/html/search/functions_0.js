var searchData=
[
  ['clear_5fconsole_21',['clear_console',['../console_8c.html#a3cffe15b7e5d10a108f1734a9640a2c7',1,'clear_console():&#160;console.c'],['../console_8h.html#a3cffe15b7e5d10a108f1734a9640a2c7',1,'clear_console():&#160;console.c']]]
];
