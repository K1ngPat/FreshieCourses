var kernel_8c =
[
    [ "main", "kernel_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "boot_info", "kernel_8c.html#a76271be06cbf672af652cef947c47cd8", null ],
    [ "malloc_lmm", "kernel_8c.html#a45c86c8d46ce54e2d13c91bcc6880724", null ]
];