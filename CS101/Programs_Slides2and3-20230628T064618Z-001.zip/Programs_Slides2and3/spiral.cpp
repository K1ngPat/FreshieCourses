#include <simplecpp>

main_program{
turtleSim(); // start the turtle simulator!
int i=1; // a counter
repeat(25){ // this is the number of L�s we want
    forward(i*10); right(90); // one segment of the L
    forward(i*10); right(90); // the second segment of L
    wait(1);
    i=i+1; // increment the counter
}
wait(20);
}

