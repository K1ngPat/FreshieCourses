#imports user written module.py and give it a different name for use here
import module as m
#Can also import only the person1 dictionary from the module as below. Commented since above already imported entire module
#from mymodule import person1

a = m.person1["age"]
print(a) 

#these are built-in modules
import platform
x = platform.system()
print(x)
#dir lists all the defined names belonging to all modules, including user defined ones 
y = dir(platform)
print(y) 

#math module with lots of math functions
import math 
x = math.sqrt(81)
y = math.floor(7.7)
z = math.pi
print(x,y,z) 

#regular expression module
import re

txt = "The rain in Spain"
x = re.search("^The.*Spain$", txt) 
txt = "The rain in Spain"
print(x)
x = re.split("\s", txt)
print(x) 

# importing sys module that handles command line arguments; be sure to give "3" arguments when running this code
import sys
  
# storing the arguments
program = sys.argv[0]
arg1 = sys.argv[1]
arg2 = sys.argv[2]
arg3 = sys.argv[3]
  
# displaying the program name
print("Program name : " + program)
  
# displaying the arguments
print("arg1 : " + arg1)
print("arg2 : " + arg2)
print("arg3 : " + arg3)
print("Number of arguments : ", len(sys.argv))
print(sys.argv)


