var searchData=
[
  ['main_11',['main',['../kernel_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'kernel.c']]],
  ['malloc_5flmm_12',['malloc_lmm',['../kernel_8c.html#a45c86c8d46ce54e2d13c91bcc6880724',1,'kernel.c']]]
];
