var searchData=
[
  ['get_5fchar_23',['get_char',['../console_8h.html#ad7ad7dd7d4b3a81fc4ec4b8a93b8de65',1,'console.h']]],
  ['get_5fcursor_24',['get_cursor',['../console_8c.html#a394130880ff20a1f88eb92494d956ccd',1,'get_cursor(int *row, int *col):&#160;console.c'],['../console_8h.html#a394130880ff20a1f88eb92494d956ccd',1,'get_cursor(int *row, int *col):&#160;console.c']]],
  ['get_5fterm_5fcolor_25',['get_term_color',['../console_8c.html#a8786be64384ee8a582a02922c6d0bd26',1,'get_term_color(int *color):&#160;console.c'],['../console_8h.html#a8786be64384ee8a582a02922c6d0bd26',1,'get_term_color(int *color):&#160;console.c']]]
];
