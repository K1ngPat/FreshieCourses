var searchData=
[
  ['putbyte_28',['putbyte',['../console_8c.html#af1ad940b06a3d54539f98436b518ceb9',1,'putbyte(char ch):&#160;console.c'],['../console_8h.html#af1ad940b06a3d54539f98436b518ceb9',1,'putbyte(char ch):&#160;console.c']]],
  ['putbytes_29',['putbytes',['../console_8c.html#ab50dfa76fef19d93cf4f9d614353e814',1,'putbytes(const char *s, int len):&#160;console.c'],['../console_8h.html#ab50dfa76fef19d93cf4f9d614353e814',1,'putbytes(const char *s, int len):&#160;console.c']]]
];
