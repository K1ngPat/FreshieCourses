var files_dup =
[
    [ "console.c", "console_8c.html", "console_8c" ],
    [ "console.h", "console_8h.html", "console_8h" ],
    [ "kernel.c", "kernel_8c.html", "kernel_8c" ]
];