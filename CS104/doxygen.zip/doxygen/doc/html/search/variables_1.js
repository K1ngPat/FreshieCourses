var searchData=
[
  ['malloc_5flmm_34',['malloc_lmm',['../kernel_8c.html#a45c86c8d46ce54e2d13c91bcc6880724',1,'kernel.c']]]
];
