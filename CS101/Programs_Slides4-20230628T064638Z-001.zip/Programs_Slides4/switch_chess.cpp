#include<iostream>
#include<stdlib.h>
using namespace std;

int main()
{
    int piece;
    int x1,y1,x2,y2;
    bool flag;

    const int pawn = 1, knight = 2, bishop = 3, rook = 4, queen = 5, king = 6;

    cout << "Enter the piece of your choice (1 = pawn, 2 = knight, 3 = bishop, 4 = rook, 5 = queen, 6 = king): "; cin >> piece;
    if (piece != pawn && piece != knight && piece != bishop && piece != rook && piece != queen && piece != king)
    {
        cout << "Invalid input for the piece"; exit(0);
    }

    cout << "Enter the (x,y) coordinates of the starting position of the piece: "; cin >> x1 >> y1;
    cout << "Enter the (x,y) coordinates of the ending position of the piece: "; cin >> x2 >> y2;

    if (x1 < 0 || x1 > 7 || y1 < 0 || y1 > 7 || x2 < 0 || x2 > 7 || y2 < 0 || y2 > 7)
    {
        cout << "Illegal piece positions!"; exit(0);
    }

    switch (piece)
    {
        case bishop: if (abs(x1-x2) == abs(y1-y2) && x1!=x2) flag = true; break;
        case rook: if ( (x1==x2 && y1!=y2) || (y1==y2 && x1!=x2)) flag = true; break;
    }

    if (flag)
    {
        cout << "The move is legal";
    }
    else
    {
        cout << "The move is illegal";
    }
}
