#include<iostream>
using namespace std;

int gcd (int m, int n){
while (m%n != 0) {
	int remainder = m%n;
	m = n; n = remainder;
}
return n;
}

int main(){
int a=10, b=4, c = 39, d=72;
cout << gcd(a,b) << endl;
cout << gcd(c,d) << endl;
}
