var searchData=
[
  ['set_5fcursor_30',['set_cursor',['../console_8c.html#a24f2e03d3bfd641d822ac411022812a8',1,'set_cursor(int row, int col):&#160;console.c'],['../console_8h.html#a24f2e03d3bfd641d822ac411022812a8',1,'set_cursor(int row, int col):&#160;console.c']]],
  ['set_5fterm_5fcolor_31',['set_term_color',['../console_8c.html#ae1ad067583402ad483584274b6c6ee3e',1,'set_term_color(int color):&#160;console.c'],['../console_8h.html#ae1ad067583402ad483584274b6c6ee3e',1,'set_term_color(int color):&#160;console.c']]],
  ['show_5fcursor_32',['show_cursor',['../console_8c.html#a1bdd62a6bef7cfd6522dc1412e162559',1,'show_cursor():&#160;console.c'],['../console_8h.html#a1bdd62a6bef7cfd6522dc1412e162559',1,'show_cursor():&#160;console.c']]]
];
