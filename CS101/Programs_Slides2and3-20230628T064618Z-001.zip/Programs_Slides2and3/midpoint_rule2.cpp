#include<iostream>
#include<cmath> // you need to include the cmath library  if you are not using simplecpp (simplecpp internally includes it)
//cmath is required for math functions like exp
using namespace std;

int main()
{
float a, b, x1, x2, delta, sumval = 0.0; // initialize summation to 0
int N = 50; // number of sub-intervals
a = 1;
b = exp(1); // value of 'e'
x1 = a; // stands for xi-1 in the formula on the previous slide
delta = (b-a)/N; //sub-interval width
x2 = a+delta; // stands for xi in the formula on the previous slide

for(int it = 0; it < N; it=it+1)
{
sumval = sumval + delta*(2/(x1+x2)); // invoking the midpoint rule for f(x) = 1/x
x1=x2; // changing the values of x_{i-1} and x_i
x2 += delta;
} // ends repeat loop

cout << "The summation is: " << sumval; // you will see this evaluates to 1
}


