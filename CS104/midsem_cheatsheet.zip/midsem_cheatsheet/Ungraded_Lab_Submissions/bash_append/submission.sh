#! /usr/bin/env bash

for i in *.out
do
echo $1>>$i
done