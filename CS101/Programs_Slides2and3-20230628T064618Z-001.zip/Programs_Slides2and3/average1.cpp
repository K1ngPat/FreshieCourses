#include<simplecpp>

main_program{
int n,a;
float avg = 0.0; // initialize average to 0 � very important!
cout << "how many numbers?"; cin >> n;
repeat(n){
cout << "enter the next number"; cin >> a;
avg = avg + a;
}
avg = avg/n;  // at the end of the loop, avg contains the sum; divide // by n to get average
cout << endl << "Their average is: " << avg;
}
