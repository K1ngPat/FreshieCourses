#include<iostream>
using namespace std;

int factorial (int n)
{
if (n == 0) return 1;
int prod=1;
for (int i = n; i > 0; i=i-1){
	prod *= i;
}
return prod;
}


int main()
{
int a=10, b=4;
cout << factorial(a) << endl;
cout << factorial(b) << endl;
}
