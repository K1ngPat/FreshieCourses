#include<simplecpp>

main_program{
int n,i=1; // i is a useful counter � we will see soon
int facval = 1; // initialize factorial value to 1 � very important!
 cout << "Enter the number whose factorial you want to compute: "; cin >> n;
repeat(n){
facval = facval * i; // accumulation
i = i+1; // sequence generation
}
cout << facval;
}
