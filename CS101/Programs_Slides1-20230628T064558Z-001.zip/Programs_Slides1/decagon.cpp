#include <simplecpp>
main_program{
turtleSim();
repeat(10){
forward(70); left(36);
}
wait(15);
}
