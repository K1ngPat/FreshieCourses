var searchData=
[
  ['boot_5finfo_33',['boot_info',['../kernel_8c.html#a76271be06cbf672af652cef947c47cd8',1,'kernel.c']]]
];
