#include <iostream>
using namespace std;

int main()
{
    int n,m,i,j;
    double avg,score;

    cout << "enter the number of students: "; cin >> n;
    cout << "enter the number of subjects: "; cin >> m;

    i = 0;
    while (i < n)
    {
        cout << "enter marks for student number: " << i << endl;
        avg = 0.0;

        j = 0;
        while (j < m)
        {
            cout << "enter marks for subject " << j << " of student " << i << ": ";
            cin >> score;
            avg += score;
            j++;
        } // close inner for loop (control variable j)
        avg = avg/m; cout << "Avg. marks for this student are: " << avg << endl;
        i++;
    } // close outer for loop (control variable i)
} // close main_program
