#include <iostream>
using namespace std;

int main()
{
bool flag; // flag indicates whether or not you want to read in another number
float avg = 0.0; int num,n=0;
do{
cout << �enter the next number: �; cin >> num;
n++;
avg += num;
cout << �do you want to continue: (yes=1), (no=0)?�; cin >> flag;
} while (flag);
avg = avg/n;
cout << �The average is � << avg;
}
