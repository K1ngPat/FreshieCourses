#include<simplecpp>

main_program{
//Write your code here
turtleSim();

forward(100);
left(90);
forward(100);
left(90);
forward(100);
left(90);
forward(100);
left(90);

wait(5);
}
