var console_8c =
[
    [ "clear_console", "console_8c.html#a3cffe15b7e5d10a108f1734a9640a2c7", null ],
    [ "draw_char", "console_8c.html#a6a4b480cb4306993718003fdaf8d84d1", null ],
    [ "get_cursor", "console_8c.html#a394130880ff20a1f88eb92494d956ccd", null ],
    [ "get_term_color", "console_8c.html#a8786be64384ee8a582a02922c6d0bd26", null ],
    [ "hide_cursor", "console_8c.html#a42702791e6da9510e4f44f33d2dad8f1", null ],
    [ "putbyte", "console_8c.html#af1ad940b06a3d54539f98436b518ceb9", null ],
    [ "putbytes", "console_8c.html#ab50dfa76fef19d93cf4f9d614353e814", null ],
    [ "set_cursor", "console_8c.html#a24f2e03d3bfd641d822ac411022812a8", null ],
    [ "set_term_color", "console_8c.html#ae1ad067583402ad483584274b6c6ee3e", null ],
    [ "show_cursor", "console_8c.html#a1bdd62a6bef7cfd6522dc1412e162559", null ]
];