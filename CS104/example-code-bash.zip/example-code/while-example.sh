#!/bin/bash

X=10

while [ $X -ge 0 ]
do
	let X=X-1
	echo $X
done

