#include<iostream>
using namespace std;

int main()
{
int m,n,i,min_mn;
cout << "Enter the numbers "; cin >> m >> n;
min_mn = min(m,n);
for (i=min_mn; i >= 2; i--){
if (m%i == 0 && n%i == 0) break;
}
cout << "Their GCD is: " << i;
}
