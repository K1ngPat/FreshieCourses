#include<iostream>
using namespace std;

// this program is the same as average1.cpp but it does not use simplecpp


int main() // if you do not use simplecpp, then you can use "main_program". Instead using int main ()
{
int n,a;
float avg = 0.0; // initialize average to 0 � very important!
cout << "how many numbers?"; cin >> n;

for(int it=0;it<n;it=it+1) // if you are using standard C++, then you have to replace "repeat(n)" by this for loop
{
cout << "enter the next number"; cin >> a;
avg = avg + a;
}

avg = avg/n;  // at the end of the loop, avg contains the sum; divide // by n to get average
cout << endl << "Their average is: " << avg;
}
