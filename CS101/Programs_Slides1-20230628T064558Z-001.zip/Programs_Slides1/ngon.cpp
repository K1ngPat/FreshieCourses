#include <simplecpp>
main_program{
int num_sides; // number of sides of the n-gon
turtleSim();
cout << "enter number of sides of the polygon"; // ask user to enter
// desired number via keyboard
cin >> num_sides; // and store in �variable� called num_sides
repeat(num_sides){ // repeat �num_sides� number of times
forward(50); left(360/num_sides);
}
wait(5);
}
