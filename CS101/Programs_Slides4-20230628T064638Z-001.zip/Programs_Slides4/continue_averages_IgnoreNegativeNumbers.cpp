#include <iostream>
using namespace std;

int main()
{
bool flag; // flag indicates whether or not you want to read in another number
float avg = 0.0; int num,n=0;
while (true){
cout << �do you want to continue: (yes=1), (no=0)?�; cin >> flag;
if (!flag) break; // ensures that the loop will terminate some time
cout << �enter the next number: �; cin >> num;
if (num < 0) continue; // ignore negative numbers - do not update n or avg
n++;
avg += num;
}
if (n > 0) {avg = avg/n;
cout << �The average is � << avg;
}
}
