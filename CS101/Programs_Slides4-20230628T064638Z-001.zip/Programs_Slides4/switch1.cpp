#include<iostream>
using namespace std;

int main()
{
//Write your code here
int month;

cin >> month;

switch (month)
{
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12: cout << "This month has 31 days"; break;

    case 2: cout << "This month has 28 or 29 days"; break;
    case 4:
    case 6:
    case 9:
    case 11: cout << "This month has 30 days"; break;
    default: cout << "Invalid input";
}

// the same switch case as above, with no break statements after each case
switch (month)
{
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12: cout << "This month has 31 days";

    case 2: cout << "This month has 28 or 29 days";
    case 4:
    case 6:
    case 9:
    case 11: cout << "This month has 30 days";
    default: cout << "Invalid input";
}

return;
}
