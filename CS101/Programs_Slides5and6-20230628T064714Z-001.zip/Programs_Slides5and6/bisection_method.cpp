#include<iostream>
#include<cmath>
using namespace std;

int main()
{
double xL = 1, xR = 2, gt; // initial interval
double epsilon = 0.001; // precision of the root�s value -- can be taken as input from the user
bool flagL, flagR;
double xM;
bool flagM;
flagL = xL*xL*xL-5 > 0; flagR = xR*xR*xR-5 > 0; // signs of f(xL) and f(xR)
if (flagL != flagR)
{
	while (xR - xL > epsilon) // until the required precision is reached
	{
		xM = (xR+xL)/2; // interval midpoint
		flagM = xM*xM*xM-5 > 0;
if (flagM != flagL) xR = xM; // signs of f(xM) and f(xL)
else if (flagM != flagR) xL = xM;
	}
}
cout << "the root is " << xL;
gt = pow(5,0.33333);
cout << endl << "ground truth value = " << gt;

cout << endl << "relative error = " << fabs(gt-xL)/fabs(gt);
}
