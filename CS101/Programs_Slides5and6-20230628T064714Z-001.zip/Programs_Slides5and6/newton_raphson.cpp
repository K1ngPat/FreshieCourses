#include<iostream>
#include<cmath>
using namespace std;

int main()
{
double x, epsilon = 0.001,gt;
double dfx,fx;
cout << "enter initial guess of root: "; cin >> x;
while (fabs(x*x*x-5) > epsilon)
{
	fx = x*x*x-5;
	dfx = 3*x*x;
	x = x - fx/dfx;
}
cout << "The root is: " << x << "and the value of the function there is: " << fx;
gt = pow(5,0.33333);
cout << endl << "ground truth value = " << gt;

cout << endl << "relative error = " << fabs(gt-x)/fabs(gt);
}
