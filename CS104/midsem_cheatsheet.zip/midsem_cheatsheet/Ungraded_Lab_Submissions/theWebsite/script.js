/* JavaScript */
function submitMessage()    {
    alert("Thank you " + document.getElementById("name").value + " (email: " + document.getElementById("email").value + ") for your message!");
}
