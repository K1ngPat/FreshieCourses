#include<simplecpp> // h below is the height of the node
void tree (int h, float H_b, float W_b, float rx, float ry){
    if (h > 0)
    {
        float LSRx = rx-W_b/4; // x coordinate of endpoint of left branch
        float RSRx = rx+W_b/4; // x coordinate of endpoint of right branch
        float SRy = ry-H_b/4; // y coordinate of endpoint of both branches

        // draw the left subtree, by means of a line
        Line Lbranch(rx,ry,LSRx,SRy); Lbranch.imprint(); wait(1);
        // draw the right subtree, by means of a line
        Line Rbranch(rx,ry,RSRx,SRy); Rbranch.imprint(); wait(1);
        tree(h-1,H_b-H_b/h,W_b/2,LSRx,SRy); // recursive call to left subtree
        tree(h-1,H_b-H_b/h,W_b/2,RSRx,SRy); // recursive call to right subtree
    }
    else return; // base case: do nothing for height = 0, i.e. leaf node.
}
main_program{
turtleSim();
left(90);
tree(5,200,200,250,250);
wait(15); }


